fx_version 'adamant'

game 'gta5'

description 'disable headshot'
author 'nuskyy'
version '0.0.1'


client_scripts{
    'config.lua',
    'client.lua',
}
